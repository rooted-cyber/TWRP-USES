echo -e "\033[1;92m"
figlet Backup
echo
echo "1.Recovery"
echo
echo "2.Boot"
echo
echo "3.Bootanimation"
echo
echo "4.Bootaudio (Below 6.0)"
echo
echo "5.Main Menu"
echo -e "\033[1;91m"
read -p 'select_option >' opt
echo -e "\e[1;93m"

if [ $opt -eq 1 ];then
clear
echo -e "\033[1;92m"
echo "please wait......."
su -c dd if=/dev/block/platform/soc/7824900.sdhci/by-name/recovery of=/data/data/com.termux/files/home/Maruf/Port/aa.img
unpackall
repackall
mv -f /data/data/com.termux/files/home/Maruf/Port/aa.img Recovery.img
su -c cp -f /data/data/com.termux/files/home/Maruf/Port/Recovery.img /sdcard/Flash/Backup
rm -f /data/data/com.termux/files/home/Maruf/Port/*
sleep 2
echo "success"
sleep 2
bash .backup.sh
fi
if [ $opt -eq 2 ];then
clear
echo -e "\033[1;92m"
echo "please wait........."
su -c dd if=/dev/block/platform/soc/7824900.sdhci/by-name/boot of=/data/data/com.termux/files/home/Maruf/Stock/bb.img
unpackall
repackall
mv -f /data/data/com.termux/files/home/Stock/bb.img Boot.img
cp -f /data/data/com.termux/files/home/Stock/Boot.img /sdcard/Flash/Backup
rm -f /data/data/com.termux/files/home/Stock/*
sleep 2
clear
echo "Success"
sleep 2
bash .backup.sh
fi
if [ $opt -eq 3 ];then
clear
echo -e "\033[1;92m"
echo "please wait......"
su -c cp -f /system/media/bootanimation.zip /sdcard/Flash/Backup
sleep 2
echo "Success"
sleep 2
bash .backup.sh
fi
if [ $opt -eq 4 ];then
clear
echo -e "\033[1;92m"
echo "please wait.........."
su -c cp -f /system/media/bootaudio.mp3 /sdcard/Flash/Backup
sleep 2
echo "Success"
sleep 2
bash .backup.sh
fi
if [ $opt -eq 5 ];then
clear
Twrp
fi

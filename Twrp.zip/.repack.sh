echo -e "\033[1;92m"
figlet Repack
echo
echo -e "\033[1;93m"
echo "1.Boot"
echo
echo "2.Recovery"
echo
echo "3.Main Menu"
echo -e "\033[1;91m"
read -p 'select_option >' opt
echo -e "\e[1;93m"

if [ $opt -eq 1 ];then
clear
echo -e "\033[1;92m"
repackall
echo "Success"
sleep 2
bash $HOME/TWRP-USES/.repack.sh
fi
if [ $opt -eq 2 ];then
clear
echo -e "\033[1;92m"
repackall
echo "Success"
sleep 2
bash $HOME/TWRP-USES/.repack.sh
fi
if [ $opt -eq 3 ];then
clear
Twrp
fi
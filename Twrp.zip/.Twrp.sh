echo -e "\033[1;92m"
figlet Twrp
echo -e "\033[1;93m"
echo 
echo "1.Flashing"
echo "2.Backup"
echo "3.Reboot"
echo "4.Unpack .img"
echo "5.Repack .img"
echo "6.Help"
echo "7.Exit"
echo -e "\033[1;91m"
read -p 'select_option >' opt
echo -e "\e[1;93m"

if [ $opt -eq 1 ];then
clear
bash .flash.sh
fi
if [ $opt -eq 2 ];then
clear
bash .backup.sh
fi
if [ $opt -eq 3 ];then
clear
bash .reboot.sh
fi
if [ $opt -eq 4 ];then
clear
bash .unpack.sh
fi
if [ $opt -eq 5 ];then
clear
bash .repack.sh
fi
if [ $opt -eq 6 ];then
clear
bash .help.sh
fi
if [ $opt -eq 7 ];then
exit
fi